# 🎨 WallPix - منصة الصور والخلفيات المتميزة

## 📋 معلومات الموقع الكاملة

### 🌐 بيانات الموقع الأساسية
- **اسم المشروع:** WallPix
- **الوصف:** منصة متكاملة لعرض وتحميل الصور والخلفيات بجودة عالية
- **الإصدار:** 1.0.0
- **التاريخ:** 13 يونيو 2026
- **الحالة:** جاهز للاستخدام

### 🔗 الروابط المهمة
- **الموقع المباشر:** https://3000-igqr6yh6mmbbq3scjwzxf-d025ef50.us1.manus.computer
- **إصدار المشروع:** 97a39cd6
- **مسار المشروع:** /home/ubuntu/wallpix

---

## 🎯 المميزات الرئيسية

### 1. الصفحات والواجهات
| الصفحة | المسار | الوصف |
|-------|--------|-------|
| الرئيسية | `/` | Hero Section مع عناصر عائمة وشريط بحث |
| المعرض | `/gallery` | عرض الصور بتخطيط Masonry Grid |
| تفاصيل الصورة | `/image/:id` | Lightbox مع معلومات الصورة وزر التحميل |
| رفع الصور | `/upload` | واجهة Drag & Drop مع فحص الملفات |
| لوحة التحكم | `/dashboard` | عرض الإحصائيات والمفضلة |
| الملف الشخصي | `/profile` | إدارة البيانات الشخصية |
| الأسعار | `/pricing` | عرض الخطط الثلاث مع FAQ |

### 2. نظام الألوان
| اللون | الكود | الاستخدام |
|------|------|----------|
| البنفسجي الأساسي | `#7C3AED` | الأزرار الرئيسية والعناوين |
| الأزرق السماوي | `#0EA5E9` | العناصر الثانوية والتدرجات |
| الأبيض النقي | `#FFFFFF` | الخلفيات في الوضع النهاري |
| الرمادي الفاتح | `#F3F4F6` | الخلفيات الثانوية والبطاقات |
| الرمادي الداكن | `#111827` | الخلفية في الوضع الليلي |

### 3. خطط الاشتراكات
| الخطة | السعر | المميزات |
|------|------|---------|
| مجاني | $0 | 5 صور شهرياً، حجم 5MB |
| Pro | $9.99 | 100 صورة شهرياً، حجم 50MB، دعم أولوي |
| Enterprise | $29.99 | صور غير محدودة، حجم غير محدود، دعم 24/7 |

---

## 🛠️ البنية التقنية

### Stack التكنولوجي
```
Frontend:
- React 19
- TypeScript
- Tailwind CSS 4
- shadcn/ui Components
- Wouter (Routing)
- Framer Motion (Animations)

Backend:
- Express.js 4
- Node.js
- tRPC 11
- Drizzle ORM

Database:
- MySQL/TiDB
- Drizzle Migrations

Authentication:
- Manus OAuth 2.0

Testing:
- Vitest
```

### هيكل المشروع
```
wallpix/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx              (الصفحة الرئيسية)
│   │   │   ├── Gallery.tsx           (المعرض)
│   │   │   ├── ImageDetail.tsx       (تفاصيل الصورة)
│   │   │   ├── Upload.tsx            (رفع الصور)
│   │   │   ├── Dashboard.tsx         (لوحة التحكم)
│   │   │   ├── Profile.tsx           (الملف الشخصي)
│   │   │   └── Pricing.tsx           (الأسعار)
│   │   ├── components/
│   │   │   └── ui/                   (مكونات shadcn/ui)
│   │   ├── App.tsx                   (التوجيه الرئيسي)
│   │   ├── index.css                 (الأنماط العامة)
│   │   └── lib/trpc.ts               (إعدادات tRPC)
│   └── index.html
├── server/
│   ├── routers.ts                    (tRPC Procedures)
│   ├── db.ts                         (دوال قاعدة البيانات)
│   ├── storage.ts                    (تخزين الملفات)
│   ├── auth.logout.test.ts           (اختبارات)
│   └── gallery.test.ts               (اختبارات المعرض)
├── drizzle/
│   ├── schema.ts                     (هيكل قاعدة البيانات)
│   └── migrations/                   (ملفات الهجرة)
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 📊 قاعدة البيانات

### الجداول الرئيسية

#### جدول المستخدمين (users)
```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  openId VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  loginMethod VARCHAR(64),
  role ENUM('user', 'admin') DEFAULT 'user',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  lastSignedIn TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### جدول الصور (images)
```sql
CREATE TABLE images (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  fileUrl VARCHAR(500) NOT NULL,
  fileKey VARCHAR(255),
  width INT,
  height INT,
  fileSize INT,
  mimeType VARCHAR(50),
  isPublic BOOLEAN DEFAULT true,
  downloadCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

#### جدول المفضلة (favorites)
```sql
CREATE TABLE favorites (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  imageId INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id),
  FOREIGN KEY (imageId) REFERENCES images(id)
);
```

#### جدول خطط الاشتراكات (subscription_plans)
```sql
CREATE TABLE subscription_plans (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) UNIQUE NOT NULL,
  displayName VARCHAR(100),
  price DECIMAL(10, 2),
  maxUploads INT,
  maxFileSize INT,
  features JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### جدول اشتراكات المستخدمين (user_subscriptions)
```sql
CREATE TABLE user_subscriptions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  planId INT NOT NULL,
  startDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  endDate TIMESTAMP,
  status ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id),
  FOREIGN KEY (planId) REFERENCES subscription_plans(id)
);
```

---

## 🔌 API Endpoints (tRPC)

### المصادقة
```
trpc.auth.me.useQuery()              - الحصول على بيانات المستخدم الحالي
trpc.auth.logout.useMutation()       - تسجيل الخروج
```

### المعرض
```
trpc.gallery.getPublicImages.useQuery()    - الحصول على الصور العامة
trpc.gallery.getImageById.useQuery()       - الحصول على صورة محددة
trpc.gallery.getUserImages.useQuery()      - الحصول على صور المستخدم
```

### المفضلة
```
trpc.favorites.list.useQuery()             - قائمة المفضلة
trpc.favorites.add.useMutation()           - إضافة للمفضلة
trpc.favorites.remove.useMutation()        - إزالة من المفضلة
trpc.favorites.isFavorited.useQuery()      - التحقق من المفضلة
```

### الاشتراكات
```
trpc.subscriptions.getPlans.useQuery()           - الحصول على الخطط
trpc.subscriptions.getUserSubscription.useQuery() - اشتراك المستخدم الحالي
```

---

## 🎨 الرسوم المتحركة

### التأثيرات المطبقة
1. **Floating Effect** - عناصر عائمة في Hero Section
2. **Fade-in** - ظهور تدريجي للعناصر
3. **Hover Effects** - تأثيرات عند التمرير على البطاقات
4. **Scale Transitions** - تكبير/تصغير سلس
5. **Color Transitions** - انتقالات لونية سلسة

### مدة الرسوم المتحركة
- الرسوم المتحركة السريعة: 100-160ms
- الرسوم المتحركة المتوسطة: 200-300ms
- الرسوم المتحركة البطيئة: 500-700ms

---

## 🧪 الاختبارات

### اختبارات Vitest
```bash
pnpm test
```

**النتائج:**
- ✅ 10 اختبارات تمر بنجاح
- ✅ اختبارات المصادقة
- ✅ اختبارات المعرض
- ✅ اختبارات الاشتراكات

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- Node.js 22+
- pnpm 10+
- MySQL/TiDB

### التثبيت
```bash
cd /home/ubuntu/wallpix
pnpm install
```

### التشغيل في بيئة التطوير
```bash
pnpm dev
```

### البناء للإنتاج
```bash
pnpm build
pnpm start
```

### تشغيل الاختبارات
```bash
pnpm test
```

---

## 📱 التوافق والاستجابة

### الأجهزة المدعومة
- ✅ الهواتف الذكية (320px+)
- ✅ الأجهزة اللوحية (768px+)
- ✅ أجهزة سطح المكتب (1024px+)
- ✅ الشاشات الكبيرة (1280px+)

### المتصفحات المدعومة
- ✅ Chrome/Edge (آخر إصدار)
- ✅ Firefox (آخر إصدار)
- ✅ Safari (آخر إصدار)

---

## 🔐 الأمان والمصادقة

### نظام المصادقة
- OAuth 2.0 من Manus
- JWT Tokens للجلسات
- HttpOnly Cookies
- CSRF Protection

### حماية البيانات
- تشفير كلمات المرور
- تحقق من الأذونات على الـ Backend
- معالجة آمنة للملفات

---

## 📈 الأداء

### تحسينات الأداء
- ✅ Lazy Loading للصور
- ✅ Code Splitting
- ✅ Optimized Bundle Size
- ✅ Caching Strategies
- ✅ Database Indexing

---

## 📞 الدعم والصيانة

### المشاكل الشائعة وحلولها

**المشكلة:** الصور لا تحميل
- **الحل:** تحقق من اتصال قاعدة البيانات والتخزين السحابي

**المشكلة:** بطء الموقع
- **الحل:** امسح الـ Cache وأعد تحميل الصفحة

**المشكلة:** مشاكل في تسجيل الدخول
- **الحل:** تحقق من معرّفات OAuth وإعدادات الـ Cookies

---

## 📝 الملفات المهمة

### ملفات الإعدادات
- `package.json` - المكتبات والنصوص
- `tsconfig.json` - إعدادات TypeScript
- `vite.config.ts` - إعدادات Vite
- `drizzle.config.ts` - إعدادات Drizzle ORM
- `tailwind.config.js` - إعدادات Tailwind CSS

### ملفات البيئة
- `.env.local` - متغيرات البيئة المحلية
- `DATABASE_URL` - رابط قاعدة البيانات
- `JWT_SECRET` - مفتاح التوقيع
- `VITE_APP_ID` - معرّف OAuth

---

## 🎯 الخطوات التالية

### التحسينات المستقبلية
1. تطبيق نظام الدفع (Stripe)
2. إضافة نظام التعليقات والتقييمات
3. تحسين محرك البحث
4. إضافة التصدير للـ PDF
5. تطبيق نظام الإشعارات
6. إضافة الوسائط المتعددة (فيديو، صوت)

---

## 📄 الترخيص

جميع الحقوق محفوظة © 2026 WallPix

---

**آخر تحديث:** 13 يونيو 2026
**الإصدار:** 1.0.0
**الحالة:** ✅ جاهز للإنتاج
