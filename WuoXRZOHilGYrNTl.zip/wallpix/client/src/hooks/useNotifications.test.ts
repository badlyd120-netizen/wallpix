import { describe, it, expect } from 'vitest';

describe('useNotifications Hook', () => {
  it('should have success method', () => {
    const mockNotification = {
      success: (title: string, message?: string) => ({
        type: 'success',
        title,
        message,
      }),
    };

    const result = mockNotification.success('Test Success', 'Test Message');
    expect(result.type).toBe('success');
    expect(result.title).toBe('Test Success');
    expect(result.message).toBe('Test Message');
  });

  it('should have error method', () => {
    const mockNotification = {
      error: (title: string, message?: string) => ({
        type: 'error',
        title,
        message,
      }),
    };

    const result = mockNotification.error('Test Error', 'Error Message');
    expect(result.type).toBe('error');
    expect(result.title).toBe('Test Error');
  });

  it('should have warning method', () => {
    const mockNotification = {
      warning: (title: string, message?: string) => ({
        type: 'warning',
        title,
        message,
      }),
    };

    const result = mockNotification.warning('Test Warning', 'Warning Message');
    expect(result.type).toBe('warning');
  });

  it('should have info method', () => {
    const mockNotification = {
      info: (title: string, message?: string) => ({
        type: 'info',
        title,
        message,
      }),
    };

    const result = mockNotification.info('Test Info', 'Info Message');
    expect(result.type).toBe('info');
  });

  it('should have loading method', () => {
    const mockNotification = {
      loading: (title: string, message?: string) => ({
        type: 'info',
        title,
        message,
        duration: 0,
      }),
    };

    const result = mockNotification.loading('Loading...', 'Please wait');
    expect(result.type).toBe('info');
    expect(result.duration).toBe(0);
  });

  it('should support options parameter', () => {
    const mockNotification = {
      success: (
        title: string,
        message?: string,
        options?: { duration?: number; action?: { label: string; onClick: () => void } }
      ) => ({
        type: 'success',
        title,
        message,
        duration: options?.duration ?? 5000,
        action: options?.action,
      }),
    };

    const mockAction = { label: 'Click', onClick: () => {} };
    const result = mockNotification.success('Test', 'Message', {
      duration: 10000,
      action: mockAction,
    });

    expect(result.duration).toBe(10000);
    expect(result.action).toBe(mockAction);
  });

  it('should have default durations', () => {
    const durations = {
      success: 5000,
      error: 7000,
      warning: 6000,
      info: 5000,
    };

    expect(durations.success).toBe(5000);
    expect(durations.error).toBe(7000);
    expect(durations.warning).toBe(6000);
    expect(durations.info).toBe(5000);
  });
});
