import { useNotification, type NotificationType } from '@/components/NotificationCenter';

interface NotificationOptions {
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const useNotifications = () => {
  const { addNotification } = useNotification();

  return {
    success: (title: string, message?: string, options?: NotificationOptions) =>
      addNotification({
        type: 'success',
        title,
        message,
        duration: options?.duration ?? 5000,
        action: options?.action,
      }),

    error: (title: string, message?: string, options?: NotificationOptions) =>
      addNotification({
        type: 'error',
        title,
        message,
        duration: options?.duration ?? 7000,
        action: options?.action,
      }),

    warning: (title: string, message?: string, options?: NotificationOptions) =>
      addNotification({
        type: 'warning',
        title,
        message,
        duration: options?.duration ?? 6000,
        action: options?.action,
      }),

    info: (title: string, message?: string, options?: NotificationOptions) =>
      addNotification({
        type: 'info',
        title,
        message,
        duration: options?.duration ?? 5000,
        action: options?.action,
      }),

    loading: (title: string, message?: string) =>
      addNotification({
        type: 'info',
        title,
        message,
        duration: 0, // لا يغلق تلقائياً
      }),
  };
};
