import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { CheckCircle, XCircle, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useNotifications } from "@/hooks/useNotifications";
import { trpc } from "@/lib/trpc";

export default function AdminPendingReviews() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const notifications = useNotifications();
  const [page, setPage] = useState(0);
  const limit = 12;

  // Check if user is admin
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spinner />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">غير مصرح</h1>
          <p className="text-muted-foreground mb-6">ليس لديك صلاحيات للوصول إلى هذه الصفحة</p>
          <Button onClick={() => setLocation("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  // Fetch pending images
  const { data: pendingImages, isLoading, refetch } = trpc.admin.getPendingImages.useQuery({
    limit,
    offset: page * limit,
  });

  // Approve mutation
  const approveMutation = trpc.admin.approveImage.useMutation({
    onSuccess: () => {
      notifications.success("تم الموافقة", "تمت الموافقة على الصورة بنجاح");
      refetch();
    },
    onError: (error) => {
      notifications.error("خطأ", error.message || "فشل الموافقة على الصورة");
    },
  });

  // Reject mutation
  const rejectMutation = trpc.admin.rejectImage.useMutation({
    onSuccess: () => {
      notifications.success("تم الرفض", "تم رفض الصورة بنجاح");
      refetch();
    },
    onError: (error) => {
      notifications.error("خطأ", error.message || "فشل رفض الصورة");
    },
  });

  const handleApprove = (imageId: number) => {
    approveMutation.mutate(imageId);
  };

  const handleReject = (imageId: number) => {
    rejectMutation.mutate(imageId);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container py-6">
          <button
            onClick={() => setLocation("/admin")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </button>
          <h1 className="text-3xl font-bold">المراجعة والموافقة</h1>
          <p className="text-muted-foreground mt-2">
            عدد الصور المعلقة: {pendingImages?.length || 0}
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Spinner />
          </div>
        ) : !pendingImages || pendingImages.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">لا توجد صور معلقة للمراجعة</p>
            <Button variant="outline" onClick={() => setLocation("/admin")}>
              العودة إلى لوحة التحكم
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingImages.map((image) => (
              <Card key={image.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                {/* Image Preview */}
                <div className="aspect-square overflow-hidden bg-muted">
                  <img
                    src={image.fileUrl}
                    alt={image.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                  />
                </div>

                {/* Image Info */}
                <div className="p-4">
                  <h3 className="font-semibold text-sm mb-2 line-clamp-2">{image.title}</h3>
                  <p className="text-xs text-muted-foreground mb-4 line-clamp-2">
                    {image.description}
                  </p>

                  {/* Metadata */}
                  <div className="text-xs text-muted-foreground mb-4 space-y-1">
                    <p>الحجم: {(image.fileSize / 1024 / 1024).toFixed(2)} MB</p>
                    <p>النوع: {image.mimeType}</p>
                    <p>تاريخ الرفع: {new Date(image.createdAt).toLocaleDateString("ar-SA")}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleApprove(image.id)}
                      disabled={approveMutation.isPending}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      موافقة
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="flex-1"
                      onClick={() => handleReject(image.id)}
                      disabled={rejectMutation.isPending}
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      رفض
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {pendingImages && pendingImages.length > 0 && (
          <div className="flex justify-center gap-2 mt-8">
            <Button
              variant="outline"
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
            >
              السابق
            </Button>
            <span className="flex items-center px-4">
              الصفحة {page + 1}
            </span>
            <Button
              variant="outline"
              onClick={() => setPage(page + 1)}
              disabled={!pendingImages || pendingImages.length < limit}
            >
              التالي
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
