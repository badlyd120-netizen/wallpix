import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, ArrowRight, Image, Heart, Zap } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import { useTheme } from "@/contexts/ThemeContext";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/">
              <a className="text-2xl font-bold text-primary">WallPix</a>
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/gallery">
                <a className="text-sm hover:text-primary transition-colors">المعرض</a>
              </Link>
              <Link href="/pricing">
                <a className="text-sm hover:text-primary transition-colors">الأسعار</a>
              </Link>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? "☀️" : "🌙"}
            </button>
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="outline">لوحة التحكم</Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button>دخول</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 -z-10">
          {/* Floating elements */}
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-secondary/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ animationDelay: "2s" }}></div>
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-accent/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ animationDelay: "4s" }}></div>
        </div>

        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            {/* Main Title */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  اكتشف وشارك أجمل الصور
                </span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                منصة متكاملة لعرض وتحميل الصور والخلفيات عالية الجودة. انضم إلى مجتمعنا وشارك إبداعاتك مع العالم.
              </p>
            </div>

            {/* Search Bar */}
            <div className="flex gap-2 max-w-md mx-auto">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن صور..."
                  className="pl-10"
                />
              </div>
              <Link href="/gallery">
                <Button>بحث</Button>
              </Link>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/gallery">
                <Button size="lg" className="gap-2">
                  استكشف المعرض
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href={isAuthenticated ? "/upload" : getLoginUrl()}>
                <Button size="lg" variant="outline" className="gap-2">
                  <Image className="w-4 h-4" />
                  رفع صورة
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/50">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">لماذا WallPix؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Image,
                title: "معرض ضخم",
                description: "ملايين الصور والخلفيات عالية الجودة من مصورين حول العالم",
              },
              {
                icon: Heart,
                title: "حفظ المفضلة",
                description: "احفظ صورك المفضلة وأنظمها في مجموعات منفصلة",
              },
              {
                icon: Zap,
                title: "سريع وآمن",
                description: "تحميل فوري وتخزين سحابي آمن لجميع صورك",
              },
            ].map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="p-6 rounded-lg border border-border hover:border-primary transition-colors">
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container max-w-2xl mx-auto text-center space-y-8">
          <h2 className="text-3xl font-bold">ابدأ الآن</h2>
          <p className="text-muted-foreground text-lg">
            انضم إلى آلاف المستخدمين الذين يستمتعون بتجربة WallPix الرائعة
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <>
                <Link href="/gallery">
                  <Button size="lg">استكشف الآن</Button>
                </Link>
                <Link href="/upload">
                  <Button size="lg" variant="outline">رفع صورة</Button>
                </Link>
              </>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button size="lg">دخول / تسجيل</Button>
                </a>
                <Link href="/gallery">
                  <Button size="lg" variant="outline">استكشف كضيف</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-8">
        <div className="container text-center text-muted-foreground text-sm">
          <p>&copy; 2026 WallPix. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
