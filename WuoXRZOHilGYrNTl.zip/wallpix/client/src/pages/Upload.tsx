import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload as UploadIcon, ArrowLeft, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useNotifications } from "@/hooks/useNotifications";
import { trpc } from "@/lib/trpc";
import { useState, useRef } from "react";

const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/webp"];
const MAX_FILE_SIZE = 50 * 1024 * 1024;

export default function Upload() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const dragRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const notifications = useNotifications();
  const uploadMutation = trpc.upload.uploadMultiple.useMutation();

  console.log("[Upload Component] Mounted, uploadMutation available:", !!uploadMutation);

  if (loading) {
    console.log("[Upload] Loading auth state...");
    return <div className="flex items-center justify-center min-h-screen">جاري التحميل...</div>;
  }

  if (!isAuthenticated) {
    console.log("[Upload] User not authenticated, redirecting...");
    return null;
  }

  console.log("[Upload] User authenticated:", user?.email);

  const validateFile = (file: File): string | null => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return "الصيغة غير مدعومة. استخدم PNG أو JPG أو WebP فقط";
    }
    if (file.size > MAX_FILE_SIZE) {
      return "حجم الملف كبير جداً. الحد الأقصى 50 MB";
    }
    return null;
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dragRef.current) {
      dragRef.current.classList.add("border-primary", "bg-primary/5");
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dragRef.current) {
      dragRef.current.classList.remove("border-primary", "bg-primary/5");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dragRef.current) {
      dragRef.current.classList.remove("border-primary", "bg-primary/5");
    }
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFiles(droppedFiles);
  };

  const handleFiles = (newFiles: File[]) => {
    const validFiles: File[] = [];
    const invalidFiles: string[] = [];

    for (const file of newFiles) {
      const error = validateFile(file);
      if (error) {
        invalidFiles.push(`${file.name}: ${error}`);
      } else {
        validFiles.push(file);
      }
    }

    if (invalidFiles.length > 0) {
      invalidFiles.forEach((error) => {
        notifications.warning("ملف غير صالح", error);
      });
    }

    if (validFiles.length > 0) {
      setFiles((prev) => [...prev, ...validFiles]);
      notifications.success(
        `تم إضافة ${validFiles.length} ملف`,
        `جاهز للرفع: ${validFiles.slice(0, 2).map(f => f.name).join(', ')}${validFiles.length > 2 ? '...' : ''}`
      );
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const removeFile = (index: number) => {
    const removedFile = files[index];
    setFiles((prev) => prev.filter((_, i) => i !== index));
    notifications.info("تم إزالة الملف", removedFile?.name);
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      notifications.warning("لا توجد ملفات", "اختر صوراً لرفعها أولاً");
      return;
    }

    setIsUploading(true);
    const loadingId = notifications.loading(
      "جاري رفع الصور...",
      `يتم رفع ${files.length} صورة`
    );

    try {
      console.log("[Upload] Starting upload process with", files.length, "files");

      // Convert files to base64 using FileReader
      const filesData = await Promise.all(
        files.map((file) => {
          return new Promise<{
            fileName: string;
            fileData: string;
            fileType: "image/png" | "image/jpeg" | "image/webp";
            title: string;
          }>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
              const base64 = (reader.result as string).split(',')[1];
              console.log("[Upload] File converted to base64:", { fileName: file.name, base64Length: base64?.length });
              resolve({
                fileName: file.name,
                fileData: base64,
                fileType: file.type as "image/png" | "image/jpeg" | "image/webp",
                title: file.name.replace(/\.[^/.]+$/, ""),
              });
            };
            reader.onerror = (error) => {
              console.error("[Upload] FileReader error:", error);
              reject(error);
            };
            reader.readAsDataURL(file);
          });
        })
      );

      // Upload using tRPC
      console.log("[Upload] Sending files to server:", filesData.length, "files");
      console.log("[Upload] File data:", filesData.map(f => ({ fileName: f.fileName, fileType: f.fileType, dataLength: f.fileData.length })));

      const result = await uploadMutation.mutateAsync({
        files: filesData,
        isPublic: true,
      });

      console.log("[Upload] Upload successful:", result);

      setFiles([]);

      // Close loading notification
      notifications.success(
        "تم رفع الصور بنجاح! 🎉",
        result.message,
        {
          action: {
            label: "عرض المعرض",
            onClick: () => setLocation("/gallery"),
          },
        }
      );

      // Auto-redirect to gallery after 2 seconds
      setTimeout(() => setLocation("/gallery"), 2000);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error("[Upload] Upload error:", {
        message: errorMessage,
        stack: error instanceof Error ? error.stack : undefined,
        filesCount: files.length,
      });
      notifications.error(
        "فشل رفع الصور",
        errorMessage || "حدث خطأ أثناء رفع الصور. يرجى المحاولة مرة أخرى."
      );
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/gallery">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold">رفع الصور</h1>
              <p className="text-muted-foreground mt-1">اختر صوراً لرفعها إلى المعرض</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Area */}
          <div className="lg:col-span-2">
            {/* Drag & Drop Area */}
            <Card
              ref={dragRef}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer hover:border-primary hover:bg-primary/5 transition-all"
            >
              <UploadIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-2xl font-bold mb-2">اسحب الصور هنا</h2>
              <p className="text-muted-foreground mb-6">أو اضغط للاختيار من جهازك</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="w-full"
              >
                اختر الصور
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept={ALLOWED_TYPES.join(",")}
                onChange={handleFileSelect}
                className="hidden"
              />
              <p className="text-xs text-muted-foreground mt-4">
                الصيغ المدعومة: PNG, JPG, WebP | الحد الأقصى: 50 MB
              </p>
            </Card>

            {/* Files List */}
            {files.length > 0 && (
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">الملفات المختارة ({files.length})</h3>
                <div className="space-y-3">
                  {files.map((file, index) => (
                    <Card key={index} className="p-4 flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </Card>
                  ))}
                </div>

                {/* Upload Button */}
                <Button
                  onClick={handleUpload}
                  disabled={isUploading}
                  className="w-full mt-6"
                  size="lg"
                >
                  {isUploading ? "جاري الرفع..." : `رفع ${files.length} صورة`}
                </Button>
              </div>
            )}
          </div>

          {/* Info Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 bg-primary/5">
              <h3 className="font-semibold mb-4">معلومات الرفع</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li>✓ الصيغ المدعومة: PNG, JPG, WebP</li>
                <li>✓ الحد الأقصى للملف: 50 MB</li>
                <li>✓ يمكنك رفع عدة صور دفعة واحدة</li>
                <li>✓ الصور تُحفظ تلقائياً بعد الموافقة</li>
                <li>✓ يمكنك إضافة وصف لكل صورة</li>
              </ul>
            </Card>

            <Card className="mt-6 p-6 bg-blue-500/5">
              <h3 className="font-semibold mb-4">نصائح</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• استخدم صور عالية الجودة</li>
                <li>• تأكد من صيغة الملف الصحيحة</li>
                <li>• أضف وصفاً واضحاً للصورة</li>
                <li>• تجنب الصور الحساسة</li>
              </ul>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
