import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const plans = [
  {
    name: "مجاني",
    price: "0",
    description: "للمبتدئين",
    features: [
      "5 صور شهرياً",
      "حجم الملف حتى 5 MB",
      "دقة قياسية",
      "بدون دعم أولوي",
    ],
    notIncluded: [
      "صور غير محدودة",
      "دقة عالية جداً",
      "دعم أولوي",
    ],
  },
  {
    name: "Pro",
    price: "9.99",
    description: "للمحترفين",
    features: [
      "100 صورة شهرياً",
      "حجم الملف حتى 50 MB",
      "دقة عالية جداً",
      "دعم أولوي",
      "إحصائيات مفصلة",
    ],
    notIncluded: [
      "صور غير محدودة",
    ],
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "29.99",
    description: "للشركات",
    features: [
      "صور غير محدودة",
      "حجم الملف غير محدود",
      "دقة عالية جداً",
      "دعم أولوي 24/7",
      "إحصائيات مفصلة",
      "API مخصص",
    ],
    notIncluded: [],
  },
];

const defaultPlans = [
  {
    name: "مجاني",
    price: "0",
    description: "للمبتدئين",
    features: [
      "5 صور شهرياً",
      "حجم الملف حتى 5 MB",
      "دقة قياسية",
      "بدون دعم أولوي",
    ],
    notIncluded: [
      "صور غير محدودة",
      "دقة عالية جداً",
      "دعم أولوي",
    ],
  },
  {
    name: "Pro",
    price: "9.99",
    description: "للمحترفين",
    features: [
      "100 صورة شهرياً",
      "حجم الملف حتى 50 MB",
      "دقة عالية جداً",
      "دعم أولوي",
      "إحصائيات مفصلة",
    ],
    notIncluded: [
      "صور غير محدودة",
    ],
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "29.99",
    description: "للشركات",
    features: [
      "صور غير محدودة",
      "حجم الملف غير محدود",
      "دقة عالية جداً",
      "دعم أولوي 24/7",
      "إحصائيات مفصلة",
      "API مخصص",
    ],
    notIncluded: [],
  },
];

const faqs = [
  {
    question: "هل يمكنني تغيير الخطة لاحقاً؟",
    answer: "نعم، يمكنك تغيير الخطة في أي وقت من لوحة التحكم الخاصة بك.",
  },
  {
    question: "ما هي طرق الدفع المتاحة؟",
    answer: "نحن نقبل بطاقات الائتمان والتحويلات البنكية والمحافظ الرقمية.",
  },
  {
    question: "هل هناك فترة تجربة مجانية؟",
    answer: "نعم، يمكنك استخدام الخطة المجانية بدون حد زمني.",
  },
  {
    question: "هل يتم استرجاع المبلغ إذا لم أكن راضياً؟",
    answer: "نعم، نوفر ضمان استرجاع المبلغ خلال 30 يوماً.",
  },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");
  const { data: plans, isLoading } = trpc.subscriptions.getPlans.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-6">
          <Link href="/">
            <a className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-4">
              <ArrowLeft className="w-4 h-4" />
              الرئيسية
            </a>
          </Link>
          <h1 className="text-3xl font-bold">خطط الأسعار</h1>
          <p className="text-muted-foreground mt-2">اختر الخطة المناسبة لك</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Billing Toggle */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <span className={billingCycle === "monthly" ? "font-bold" : "text-muted-foreground"}>
            شهري
          </span>
          <button
            onClick={() => setBillingCycle(billingCycle === "monthly" ? "yearly" : "monthly")}
            className="relative inline-flex h-8 w-14 items-center rounded-full bg-muted"
          >
            <span
              className={`inline-block h-6 w-6 transform rounded-full bg-primary transition-transform ${
                billingCycle === "yearly" ? "translate-x-7" : "translate-x-1"
              }`}
            />
          </button>
          <span className={billingCycle === "yearly" ? "font-bold" : "text-muted-foreground"}>
            سنوي (وفّر 20%)
          </span>
        </div>

        {/* Pricing Cards */}
        {isLoading ? (
          <div className="flex items-center justify-center min-h-96">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {defaultPlans.map((plan: any) => (
            <Card
              key={plan.name}
              className={`p-8 flex flex-col ${
                plan.highlighted ? "border-primary border-2 relative" : ""
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                  الأكثر شهرة
                </div>
              )}

              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-muted-foreground text-sm mb-4">{plan.description}</p>

              <div className="mb-6">
                <span className="text-4xl font-bold">${plan.price}</span>
                <span className="text-muted-foreground">/شهر</span>
              </div>

              <Button
                className="w-full mb-6"
                variant={plan.highlighted ? "default" : "outline"}
              >
                اختر الخطة
              </Button>

              <div className="space-y-3 flex-1">
                <p className="font-semibold text-sm mb-4">المميزات:</p>
                {plan.features.map((feature: string) => (
                  <div key={feature} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
                {plan.notIncluded.map((feature: string) => (
                  <div key={feature} className="flex items-start gap-3 opacity-50">
                    <span className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0">✕</span>
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
        )}

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">الأسئلة الشائعة</h2>
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-border rounded-lg px-4">
                <AccordionTrigger className="hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </main>
    </div>
  );
}
