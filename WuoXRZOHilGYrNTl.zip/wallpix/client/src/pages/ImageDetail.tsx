import { useParams } from "wouter";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Download, Heart, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function ImageDetail() {
  const params = useParams();
  const imageId = params?.id;
  const [isLoading, setIsLoading] = useState(true);
  const [isFavorited, setIsFavorited] = useState(false);

  useEffect(() => {
    // TODO: Fetch image details
    setIsLoading(false);
  }, [imageId]);

  const handleDownload = () => {
    toast.success("جاري تحميل الصورة...");
    // TODO: Implement download functionality
  };

  const handleFavorite = () => {
    setIsFavorited(!isFavorited);
    toast.success(isFavorited ? "تم الحذف من المفضلة" : "تم الإضافة إلى المفضلة");
    // TODO: Implement favorite functionality
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <Link href="/gallery">
              <a className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
                <ArrowLeft className="w-4 h-4" />
                العودة
              </a>
            </Link>
            <div className="flex gap-2">
              <Button
                variant={isFavorited ? "default" : "outline"}
                size="icon"
                onClick={handleFavorite}
              >
                <Heart className="w-4 h-4" fill={isFavorited ? "currentColor" : "none"} />
              </Button>
              <Button onClick={handleDownload} className="gap-2">
                <Download className="w-4 h-4" />
                تحميل
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Image Lightbox */}
      <main className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center min-h-96">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Image */}
            <div className="lg:col-span-2">
              <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
                <img
                  src="/placeholder.jpg"
                  alt="Image"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Details */}
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">عنوان الصورة</h1>
                <p className="text-muted-foreground">وصف الصورة يأتي هنا</p>
              </div>

              <div className="space-y-2 p-4 bg-card rounded-lg">
                <p className="text-sm text-muted-foreground">معلومات الصورة</p>
                <div className="space-y-1 text-sm">
                  <p>الحجم: 1920 x 1080</p>
                  <p>الصيغة: JPG</p>
                  <p>حجم الملف: 2.5 MB</p>
                  <p>التحميلات: 150</p>
                </div>
              </div>

              <Button className="w-full" size="lg" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />
                تحميل الصورة بالجودة الأصلية
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
