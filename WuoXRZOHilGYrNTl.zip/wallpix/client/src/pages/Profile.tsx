import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Save } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function Profile() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
  });

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">جاري التحميل...</div>;
  }

  if (!isAuthenticated) {
    return null;
  }

  const handleSave = async () => {
    // TODO: Implement save profile
    toast.success("تم حفظ البيانات بنجاح");
    setIsEditing(false);
  };

  const handleLogout = () => {
    logout();
    setLocation("/");
    toast.success("تم تسجيل الخروج بنجاح");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-6">
          <Link href="/dashboard">
            <a className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-4">
              <ArrowLeft className="w-4 h-4" />
              العودة
            </a>
          </Link>
          <h1 className="text-3xl font-bold">الملف الشخصي</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Profile Card */}
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-6">معلومات الحساب</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">الاسم</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  disabled={!isEditing}
                  placeholder="أدخل اسمك"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                <Input
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  disabled={!isEditing}
                  placeholder="أدخل بريدك الإلكتروني"
                  type="email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">معرّف المستخدم</label>
                <Input
                  value={user?.openId || ""}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div className="flex gap-2 pt-4">
                {isEditing ? (
                  <>
                    <Button onClick={handleSave} className="gap-2">
                      <Save className="w-4 h-4" />
                      حفظ التغييرات
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditing(false);
                        setFormData({
                          name: user?.name || "",
                          email: user?.email || "",
                        });
                      }}
                    >
                      إلغاء
                    </Button>
                  </>
                ) : (
                  <Button onClick={() => setIsEditing(true)} variant="outline">
                    تعديل البيانات
                  </Button>
                )}
              </div>
            </div>
          </Card>

          {/* Danger Zone */}
          <Card className="p-6 border-destructive/50">
            <h2 className="text-xl font-bold mb-4 text-destructive">منطقة الخطر</h2>
            <p className="text-muted-foreground mb-4">
              تسجيل الخروج من حسابك على جميع الأجهزة
            </p>
            <Button variant="destructive" onClick={handleLogout}>
              تسجيل الخروج
            </Button>
          </Card>
        </div>
      </main>
    </div>
  );
}
