import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Search, Download, Heart, ChevronDown } from "lucide-react";
import { Link } from "wouter";
import { useNotifications } from "@/hooks/useNotifications";

interface ImageItem {
  id: number;
  title: string;
  fileUrl: string;
  width?: number;
  height?: number;
  downloadCount: number;
  userId: number;
  fileName: string;
  mimeType: string;
  fileSize: number;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export default function Gallery() {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const notifications = useNotifications();

  // Fetch public images using tRPC
  const getPublicImagesQuery = trpc.gallery.getPublicImages.useQuery(
    { limit: 20, offset }
  );

  useEffect(() => {
    if (getPublicImagesQuery.data) {
      console.log("[Gallery] Fetched images:", getPublicImagesQuery.data.length);
      if (offset === 0) {
        setImages(getPublicImagesQuery.data as ImageItem[]);
      } else {
        setImages((prev) => [...prev, ...(getPublicImagesQuery.data as ImageItem[])]);
      }
      setHasMore((getPublicImagesQuery.data as ImageItem[]).length === 20);
    }
  }, [getPublicImagesQuery.data]);

  useEffect(() => {
    if (getPublicImagesQuery.error) {
      console.error("[Gallery] Failed to fetch images:", getPublicImagesQuery.error);
      notifications.error(
        "خطأ في التحميل",
        "فشل تحميل الصور. يرجى المحاولة مرة أخرى."
      );
    }
  }, [getPublicImagesQuery.error]);



  const handleAddFavorite = (imageId: number) => {
    const isFav = favorites.includes(imageId);
    if (isFav) {
      setFavorites((prev) => prev.filter((id) => id !== imageId));
      notifications.info("تم إزالة من المفضلة", "تم إزالة الصورة من المفضلة");
    } else {
      setFavorites((prev) => [...prev, imageId]);
      notifications.success("تمت الإضافة", "تم إضافة الصورة إلى المفضلة ❤️");
    }
  };

  const handleDownload = (image: ImageItem) => {
    console.log("[Gallery] Downloading image:", image.id);
    notifications.success(
      "جاري التحميل",
      `تحميل: ${image.title}`,
      { duration: 3000 }
    );

    // Create a link to download the image
    if (image.fileUrl) {
      const link = document.createElement("a");
      link.href = image.fileUrl;
      link.download = `${image.title}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleLoadMore = () => {
    setOffset((prev) => prev + 20);
  };

  const filteredImages = images.filter((img) =>
    (img.title?.toLowerCase() || "").includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="container py-4">
          <div className="flex items-center justify-between gap-4">
            <Link href="/">
              <a className="text-2xl font-bold text-primary">WallPix</a>
            </Link>
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن صور..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Link href="/upload">
              <Button>رفع صورة</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {isLoading && images.length === 0 ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">جاري تحميل الصور...</p>
            </div>
          </div>
        ) : filteredImages.length === 0 ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <p className="text-lg text-muted-foreground mb-4">لا توجد صور متاحة</p>
              <Link href="/upload">
                <Button>رفع صورة الآن</Button>
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Gallery Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredImages.map((image) => (
                <div
                  key={image.id}
                  className="group relative overflow-hidden rounded-lg bg-muted aspect-square cursor-pointer transition-transform hover:scale-105"
                >
                  {/* Image */}
                  <img
                    src={image.fileUrl}
                    alt={image.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      console.error("[Gallery] Image load error:", image.id);
                      e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400'%3E%3Crect fill='%23f3f4f6' width='400' height='400'/%3E%3Ctext x='50%25' y='50%25' font-size='20' fill='%236b7280' text-anchor='middle' dy='.3em'%3Eفشل تحميل الصورة%3C/text%3E%3C/svg%3E";
                    }}
                  />

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-end justify-between p-4 opacity-0 group-hover:opacity-100">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="bg-white/20 hover:bg-white/30 text-white"
                        onClick={() => handleDownload(image)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="bg-white/20 hover:bg-white/30 text-white"
                        onClick={() => handleAddFavorite(image.id)}
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            favorites.includes(image.id) ? "fill-current" : ""
                          }`}
                        />
                      </Button>
                    </div>
                  </div>

                  {/* Title */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                    <p className="text-white text-sm font-medium truncate">
                      {image.title}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Load More Button */}
            {hasMore && (
              <div className="flex justify-center mt-8">
                <Button
                  onClick={handleLoadMore}
                  disabled={getPublicImagesQuery.isLoading}
                  variant="outline"
                >
                  {getPublicImagesQuery.isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري التحميل...
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-4 h-4 mr-2" />
                      تحميل المزيد
                    </>
                  )}
                </Button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
