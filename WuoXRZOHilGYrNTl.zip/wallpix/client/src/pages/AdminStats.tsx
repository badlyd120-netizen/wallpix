import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { ArrowLeft, Images, Users, Download } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function AdminStats() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: stats, isLoading } = trpc.admin.getStats.useQuery();

  // Check if user is admin
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spinner />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">غير مصرح</h1>
          <p className="text-muted-foreground mb-6">ليس لديك صلاحيات للوصول إلى هذه الصفحة</p>
          <Button onClick={() => setLocation("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container py-6">
          <button
            onClick={() => setLocation("/admin")}
            className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </button>
          <h1 className="text-3xl font-bold">الإحصائيات</h1>
          <p className="text-muted-foreground mt-2">ملخص إحصائيات النظام</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Spinner />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Total Images Card */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">إجمالي الصور</p>
                    <p className="text-4xl font-bold">{stats?.totalImages || 0}</p>
                  </div>
                  <div className="bg-primary/10 p-4 rounded-lg">
                    <Images className="w-8 h-8 text-primary" />
                  </div>
                </div>
              </Card>

              {/* Total Users Card */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">إجمالي المستخدمين</p>
                    <p className="text-4xl font-bold">{stats?.totalUsers || 0}</p>
                  </div>
                  <div className="bg-blue-500/10 p-4 rounded-lg">
                    <Users className="w-8 h-8 text-blue-500" />
                  </div>
                </div>
              </Card>

              {/* Total Downloads Card */}
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">إجمالي التحميلات</p>
                    <p className="text-4xl font-bold">{stats?.totalDownloads || 0}</p>
                  </div>
                  <div className="bg-green-500/10 p-4 rounded-lg">
                    <Download className="w-8 h-8 text-green-500" />
                  </div>
                </div>
              </Card>
            </div>

            {/* Additional Stats Section */}
            <Card className="mt-8 p-6">
              <h2 className="text-xl font-semibold mb-4">معلومات إضافية</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">متوسط التحميلات لكل صورة</span>
                  <span className="font-semibold">
                    {stats && stats.totalImages > 0
                      ? (stats.totalDownloads / stats.totalImages).toFixed(2)
                      : 0}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">عدد الصور لكل مستخدم</span>
                  <span className="font-semibold">
                    {stats && stats.totalUsers > 0
                      ? (stats.totalImages / stats.totalUsers).toFixed(2)
                      : 0}
                  </span>
                </div>
              </div>
            </Card>

            {/* Quick Actions */}
            <div className="mt-8 flex gap-4 justify-center">
              <Button size="lg" onClick={() => setLocation("/admin/reviews")}>
                المراجعة والموافقة
              </Button>
              <Button size="lg" variant="outline" onClick={() => setLocation("/admin")}>
                لوحة التحكم
              </Button>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
