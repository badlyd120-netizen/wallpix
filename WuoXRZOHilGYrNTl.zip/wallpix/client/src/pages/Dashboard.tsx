import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, Heart, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [favorites, setFavorites] = useState([]);
  const [isLoadingFavorites, setIsLoadingFavorites] = useState(true);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/");
      toast.error("يجب تسجيل الدخول أولاً");
    }
  }, [loading, isAuthenticated, setLocation]);

  useEffect(() => {
    if (isAuthenticated) {
      // TODO: Fetch user favorites
      setIsLoadingFavorites(false);
    }
  }, [isAuthenticated]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">لوحة التحكم</h1>
              <p className="text-muted-foreground mt-1">مرحباً، {user?.name || "المستخدم"}</p>
            </div>
            <div className="flex gap-2">
              <Link href="/upload">
                <Button className="gap-2">
                  <Upload className="w-4 h-4" />
                  رفع صورة جديدة
                </Button>
              </Link>
              <Button
                variant="outline"
                onClick={() => {
                  logout();
                  setLocation("/");
                }}
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {/* Stats Cards */}
          <div className="bg-card p-6 rounded-lg border border-border">
            <p className="text-muted-foreground text-sm mb-2">إجمالي الصور</p>
            <p className="text-3xl font-bold">0</p>
          </div>
          <div className="bg-card p-6 rounded-lg border border-border">
            <p className="text-muted-foreground text-sm mb-2">المفضلة</p>
            <p className="text-3xl font-bold">{favorites.length}</p>
          </div>
          <div className="bg-card p-6 rounded-lg border border-border">
            <p className="text-muted-foreground text-sm mb-2">الخطة الحالية</p>
            <p className="text-3xl font-bold">مجاني</p>
          </div>
        </div>

        {/* Favorites Section */}
        <div>
          <h2 className="text-2xl font-bold mb-4">المفضلة</h2>
          {isLoadingFavorites ? (
            <div className="flex items-center justify-center min-h-96">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : favorites.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-96 gap-4">
              <Heart className="w-12 h-12 text-muted-foreground" />
              <p className="text-muted-foreground text-lg">لا توجد صور مفضلة</p>
              <Link href="/gallery">
                <Button>استكشف المعرض</Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {/* Favorite images will be displayed here */}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
