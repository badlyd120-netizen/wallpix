import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { BarChart3, CheckCircle, LogOut, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function AdminDashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { data: stats, isLoading } = trpc.admin.getStats.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      setLocation("/");
    },
  });

  // Check if user is admin
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spinner />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">غير مصرح</h1>
          <p className="text-muted-foreground mb-6">ليس لديك صلاحيات للوصول إلى هذه الصفحة</p>
          <Button onClick={() => setLocation("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container py-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">لوحة التحكم الإدارية</h1>
            <p className="text-muted-foreground mt-2">مرحباً بك، {user?.name || "المدير"}</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            تسجيل خروج
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-primary/10 to-primary/5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-2">إجمالي الصور</p>
                <p className="text-3xl font-bold">{stats?.totalImages || 0}</p>
              </div>
              <div className="bg-primary/20 p-3 rounded-lg">
                <BarChart3 className="w-6 h-6 text-primary" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-500/10 to-blue-500/5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-2">إجمالي المستخدمين</p>
                <p className="text-3xl font-bold">{stats?.totalUsers || 0}</p>
              </div>
              <div className="bg-blue-500/20 p-3 rounded-lg">
                <Settings className="w-6 h-6 text-blue-500" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-500/10 to-green-500/5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm mb-2">إجمالي التحميلات</p>
                <p className="text-3xl font-bold">{stats?.totalDownloads || 0}</p>
              </div>
              <div className="bg-green-500/20 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
            </div>
          </Card>
        </div>

        {/* Admin Menu */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pending Reviews Card */}
          <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer group">
            <div
              onClick={() => setLocation("/admin/reviews")}
              className="block"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-primary/10 p-4 rounded-lg group-hover:bg-primary/20 transition-colors">
                  <CheckCircle className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">المراجعة والموافقة</h2>
                  <p className="text-muted-foreground text-sm">مراجعة الصور المعلقة</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                قم بمراجعة الصور المرفوعة من قبل المستخدمين والموافقة عليها أو رفضها
              </p>
              <Button className="w-full">
                الذهاب إلى المراجعة
              </Button>
            </div>
          </Card>

          {/* Stats Card */}
          <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer group">
            <div
              onClick={() => setLocation("/admin/stats")}
              className="block"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-blue-500/10 p-4 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                  <BarChart3 className="w-8 h-8 text-blue-500" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">الإحصائيات</h2>
                  <p className="text-muted-foreground text-sm">إحصائيات النظام</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                عرض إحصائيات شاملة عن الصور والمستخدمين والتحميلات
              </p>
              <Button className="w-full" variant="outline">
                عرض الإحصائيات
              </Button>
            </div>
          </Card>
        </div>

        {/* Footer Info */}
        <Card className="mt-8 p-6 bg-muted/50">
          <h3 className="font-semibold mb-3">معلومات مهمة</h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>✓ أنت مسجل دخول كمدير النظام</li>
            <li>✓ لديك صلاحيات كاملة لإدارة الموقع</li>
            <li>✓ يمكنك الموافقة على الصور أو رفضها</li>
            <li>✓ يمكنك عرض إحصائيات النظام الكاملة</li>
          </ul>
        </Card>
      </main>
    </div>
  );
}
