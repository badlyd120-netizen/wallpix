import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { NotificationProvider } from "./components/NotificationCenter";
import Home from "./pages/Home";
import Gallery from "./pages/Gallery";
import ImageDetail from "./pages/ImageDetail";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Pricing from "./pages/Pricing";
import Upload from "./pages/Upload";
import AdminDashboard from "./pages/AdminDashboard";
import AdminPendingReviews from "./pages/AdminPendingReviews";
import AdminStats from "./pages/AdminStats";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/gallery"} component={Gallery} />
      <Route path={"/image/:id"} component={ImageDetail} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/pricing"} component={Pricing} />
      <Route path={"/upload"} component={Upload} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/admin/reviews"} component={AdminPendingReviews} />
      <Route path={"/admin/stats"} component={AdminStats} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable
      >
        <NotificationProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </NotificationProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
