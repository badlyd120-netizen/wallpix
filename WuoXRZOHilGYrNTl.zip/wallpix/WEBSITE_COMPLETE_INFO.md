# 📊 معلومات موقع WallPix الشاملة

## 🌐 معلومات الموقع الأساسية

| المعلومة | القيمة |
|---------|--------|
| **اسم الموقع** | WallPix - منصة الصور والخلفيات المتميزة |
| **الرابط الرئيسي** | https://3000-igqr6yh6mmbbq3scjwzxf-d025ef50.us1.manus.computer |
| **النطاق المخصص** | wallpixapp-pcnfztpy.manus.space |
| **الإصدار الحالي** | 5af3bd63 |
| **الحالة** | 🟢 قيد التشغيل |
| **اللغة** | العربية |
| **الوضع** | ليلي ونهاري |

---

## 🎨 نظام الألوان والهوية البصرية

### الألوان الأساسية

| اللون | الكود | الاستخدام |
|------|------|----------|
| **البنفسجي الأساسي** | `#7C3AED` | الأزرار الرئيسية والعناوين |
| **الأزرق السماوي** | `#0EA5E9` | العناصر الثانوية والتدرجات |
| **الأبيض النقي** | `#FFFFFF` | الخلفيات في الوضع النهاري |
| **الرمادي الفاتح** | `#F3F4F6` | الخلفيات الثانوية والبطاقات |
| **الرمادي الداكن** | `#111827` | الخلفية الأساسية في الوضع الليلي |

### الخطوط المستخدمة

- **Inter**: للنصوص العادية والواجهات
- **Poppins**: للعناوين الكبيرة والبارزة

---

## 📱 الصفحات والمسارات

### الصفحات الرئيسية

| الصفحة | المسار | الوصف |
|-------|--------|-------|
| **الرئيسية** | `/` | Hero Section مع عناصر عائمة |
| **المعرض** | `/gallery` | عرض الصور بتخطيط Masonry |
| **تفاصيل الصورة** | `/image/:id` | Lightbox وزر التحميل |
| **رفع الصور** | `/upload` | Drag & Drop للرفع |
| **لوحة التحكم** | `/dashboard` | إحصائيات والمفضلة |
| **الملف الشخصي** | `/profile` | إدارة البيانات الشخصية |
| **الأسعار** | `/pricing` | الخطط الثلاث و FAQ |
| **الخطأ 404** | `/404` | صفحة الخطأ |

---

## 🗄️ قاعدة البيانات

### الجداول الرئيسية

#### 1. جدول المستخدمين (users)
```sql
- id: INT (Primary Key)
- openId: VARCHAR (Unique)
- name: TEXT
- email: VARCHAR
- loginMethod: VARCHAR
- role: ENUM ('user', 'admin')
- createdAt: TIMESTAMP
- updatedAt: TIMESTAMP
- lastSignedIn: TIMESTAMP
```

#### 2. جدول الصور (images)
```sql
- id: INT (Primary Key)
- userId: INT (Foreign Key)
- title: VARCHAR
- description: TEXT
- fileUrl: VARCHAR
- width: INT
- height: INT
- fileSize: INT
- downloadCount: INT
- isPublic: BOOLEAN
- createdAt: TIMESTAMP
- updatedAt: TIMESTAMP
```

#### 3. جدول المفضلة (favorites)
```sql
- id: INT (Primary Key)
- userId: INT (Foreign Key)
- imageId: INT (Foreign Key)
- createdAt: TIMESTAMP
```

#### 4. جدول خطط الاشتراكات (subscriptionPlans)
```sql
- id: INT (Primary Key)
- name: VARCHAR
- description: TEXT
- price: DECIMAL
- features: JSON
- createdAt: TIMESTAMP
```

#### 5. جدول اشتراكات المستخدمين (userSubscriptions)
```sql
- id: INT (Primary Key)
- userId: INT (Foreign Key)
- planId: INT (Foreign Key)
- startDate: TIMESTAMP
- endDate: TIMESTAMP
- isActive: BOOLEAN
- createdAt: TIMESTAMP
```

---

## 🔌 API Endpoints (tRPC)

### المصادقة
```
- auth.me → الحصول على بيانات المستخدم الحالي
- auth.logout → تسجيل الخروج
```

### المعرض
```
- gallery.getPublicImages → الحصول على الصور العامة
- gallery.getImageById → الحصول على صورة محددة
- gallery.getUserImages → الحصول على صور المستخدم
- gallery.uploadImage → رفع صورة جديدة
- gallery.deleteImage → حذف صورة
```

### المفضلة
```
- favorites.list → قائمة المفضلة
- favorites.add → إضافة إلى المفضلة
- favorites.remove → إزالة من المفضلة
- favorites.isFavorited → التحقق من المفضلة
```

### الاشتراكات
```
- subscriptions.getPlans → الحصول على الخطط المتاحة
- subscriptions.getUserSubscription → اشتراك المستخدم الحالي
- subscriptions.subscribe → الاشتراك في خطة
```

---

## 🎬 نظام الإشعارات المخصص

### أنواع الإشعارات

#### 1. إشعار النجاح ✅
```typescript
notifications.success('العنوان', 'الرسالة', { duration: 5000 });
```
- **اللون**: أخضر
- **المدة الافتراضية**: 5 ثواني
- **الأيقونة**: CheckCircle

#### 2. إشعار الخطأ ❌
```typescript
notifications.error('العنوان', 'الرسالة', { duration: 7000 });
```
- **اللون**: أحمر
- **المدة الافتراضية**: 7 ثواني
- **الأيقونة**: AlertCircle

#### 3. إشعار التحذير ⚠️
```typescript
notifications.warning('العنوان', 'الرسالة', { duration: 6000 });
```
- **اللون**: أصفر
- **المدة الافتراضية**: 6 ثواني
- **الأيقونة**: AlertTriangle

#### 4. إشعار المعلومات ℹ️
```typescript
notifications.info('العنوان', 'الرسالة', { duration: 5000 });
```
- **اللون**: أزرق
- **المدة الافتراضية**: 5 ثواني
- **الأيقونة**: Info

#### 5. إشعار التحميل 🔄
```typescript
const loadingId = notifications.loading('جاري...', 'يرجى الانتظار');
```
- **اللون**: أزرق
- **المدة**: لا يغلق تلقائياً
- **الأيقونة**: Info

### خصائص الإشعارات

```typescript
interface NotificationOptions {
  duration?: number;  // مدة الظهور بالميلي ثانية
  action?: {
    label: string;    // نص الزر
    onClick: () => void;  // دالة عند النقر
  };
}
```

### أمثلة الاستخدام

```typescript
// مثال 1: رفع صورة
notifications.success(
  'تم الرفع بنجاح! 🎉',
  'تم رفع 3 صور',
  {
    action: {
      label: 'عرض المعرض',
      onClick: () => navigate('/gallery')
    }
  }
);

// مثال 2: خطأ في الملف
notifications.warning(
  'ملف غير صالح',
  'الصيغة غير مدعومة. استخدم PNG أو JPG'
);

// مثال 3: عملية جاري تنفيذها
const loadingId = notifications.loading(
  'جاري المعالجة...',
  'يرجى الانتظار'
);
```

---

## 🎨 الرسوم المتحركة

### الرسوم المتحركة المستخدمة

| الرسم المتحرك | المدة | الاستخدام |
|-------------|------|----------|
| **Fade-in** | 300ms | ظهور الصور والعناصر |
| **Slide-in** | 300ms | ظهور الإشعارات |
| **Scale** | 200ms | تفاعل الأزرار |
| **Floating** | 3s | عناصر عائمة في Hero |
| **Pulse** | 2s | تأثير النبض على الأيقونات |

### الإعدادات

```css
/* Ease-out للظهور */
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);

/* Ease-in-out للحركة */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
```

---

## 🔐 المصادقة والأمان

### نظام المصادقة
- **نوع**: Manus OAuth 2.0
- **الجلسات**: Cookie-based
- **التوقيع**: JWT Secret

### الأدوار
- **user**: مستخدم عادي
- **admin**: مسؤول الموقع

---

## 📊 خطط الاشتراكات

### الخطة المجانية
- **السعر**: مجاني
- **الصور المسموحة**: 10 صور
- **حجم الملف**: 5 MB
- **التحميلات**: 100 تحميل/شهر
- **المفضلة**: ✓

### خطة Pro
- **السعر**: $9.99/شهر
- **الصور المسموحة**: 1000 صورة
- **حجم الملف**: 50 MB
- **التحميلات**: غير محدود
- **المفضلة**: ✓
- **الأولوية**: ✓

### خطة Enterprise
- **السعر**: $49.99/شهر
- **الصور المسموحة**: غير محدود
- **حجم الملف**: 200 MB
- **التحميلات**: غير محدود
- **المفضلة**: ✓
- **الأولوية**: ✓
- **الدعم**: 24/7

---

## 🛠️ التقنيات المستخدمة

### Frontend
- **React 19**: مكتبة واجهات المستخدم
- **TypeScript**: لغة البرمجة
- **Tailwind CSS 4**: نظام الأنماط
- **shadcn/ui**: مكتبة المكونات
- **Framer Motion**: الرسوم المتحركة
- **Wouter**: التوجيه
- **tRPC**: الاتصال بـ Backend

### Backend
- **Express.js 4**: خادم الويب
- **tRPC 11**: API الآمنة
- **Drizzle ORM**: إدارة قاعدة البيانات
- **MySQL/TiDB**: قاعدة البيانات

### Testing
- **Vitest**: اختبارات الوحدة

---

## 📁 هيكل المشروع

```
wallpix/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx
│   │   │   ├── Gallery.tsx
│   │   │   ├── ImageDetail.tsx
│   │   │   ├── Upload.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Profile.tsx
│   │   │   ├── Pricing.tsx
│   │   │   └── NotFound.tsx
│   │   ├── components/
│   │   │   ├── NotificationCenter.tsx
│   │   │   ├── DashboardLayout.tsx
│   │   │   └── ui/
│   │   ├── hooks/
│   │   │   ├── useNotifications.ts
│   │   │   └── useNotifications.test.ts
│   │   ├── App.tsx
│   │   ├── index.css
│   │   └── main.tsx
│   └── index.html
├── server/
│   ├── routers.ts
│   ├── db.ts
│   ├── gallery.test.ts
│   └── _core/
├── drizzle/
│   ├── schema.ts
│   └── migrations/
├── shared/
│   ├── const.ts
│   └── types.ts
└── package.json
```

---

## 🚀 الأوامر المهمة

```bash
# التطوير
pnpm dev

# البناء
pnpm build

# الاختبارات
pnpm test

# التحقق من TypeScript
pnpm check

# التنسيق
pnpm format

# إنشاء الهجرات
pnpm drizzle-kit generate
```

---

## 📈 الإحصائيات

| المقياس | القيمة |
|--------|--------|
| **عدد الصفحات** | 8 صفحات |
| **عدد المكونات** | 50+ مكون |
| **عدد الـ Procedures** | 15 procedure |
| **عدد الجداول** | 5 جداول |
| **عدد الاختبارات** | 10+ اختبار |
| **حجم الملف (ZIP)** | 263 KB |

---

## 🔗 الروابط المهمة

| الرابط | الوصف |
|--------|-------|
| **الموقع الرئيسي** | https://3000-igqr6yh6mmbbq3scjwzxf-d025ef50.us1.manus.computer |
| **النطاق المخصص** | wallpixapp-pcnfztpy.manus.space |
| **لوحة التحكم** | `/dashboard` |
| **المعرض** | `/gallery` |
| **الأسعار** | `/pricing` |

---

## 📞 معلومات الدعم

### المستندات
- `README_AR.md` - دليل شامل باللغة العربية
- `QUICK_START.md` - دليل البدء السريع
- `NOTIFICATIONS_GUIDE.md` - دليل نظام الإشعارات
- `PROJECT_STRUCTURE.md` - هيكل المشروع

### الملفات الرئيسية
- `package.json` - المكتبات والأوامر
- `drizzle/schema.ts` - هيكل قاعدة البيانات
- `server/routers.ts` - API Endpoints
- `client/src/App.tsx` - التوجيه الرئيسي

---

## ✅ قائمة المميزات المنجزة

- [x] الصفحة الرئيسية مع Hero Section
- [x] معرض الصور بتخطيط Masonry
- [x] صفحة تفاصيل الصورة مع Lightbox
- [x] واجهة رفع الصور مع Drag & Drop
- [x] لوحة التحكم والملف الشخصي
- [x] صفحة الأسعار والاشتراكات
- [x] نظام الإشعارات المخصص
- [x] الوضع الليلي والنهاري
- [x] قاعدة البيانات المتكاملة
- [x] نظام المصادقة OAuth
- [x] tRPC API الكاملة
- [x] الرسوم المتحركة السلسة
- [x] الاختبارات Vitest

---

**آخر تحديث:** 13 يونيو 2026  
**الإصدار:** 5af3bd63  
**الحالة:** ✅ جاهز للاستخدام
