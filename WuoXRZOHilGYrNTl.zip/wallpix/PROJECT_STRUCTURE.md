# 📁 هيكل مشروع WallPix الشامل

## 🎯 نظرة عامة على المشروع

```
wallpix/
├── 📂 client/                          # واجهة المستخدم (React Frontend)
├── 📂 server/                          # الخادم (Express Backend)
├── 📂 drizzle/                         # قاعدة البيانات (ORM)
├── 📂 shared/                          # الكود المشترك
├── 📂 storage/                         # إدارة التخزين السحابي
├── 📄 package.json                     # المكتبات والنصوص
├── 📄 tsconfig.json                    # إعدادات TypeScript
├── 📄 vite.config.ts                   # إعدادات Vite
├── 📄 tailwind.config.js               # إعدادات Tailwind CSS
└── 📄 vitest.config.ts                 # إعدادات الاختبارات
```

---

## 📂 تفصيل الهيكل الكامل

### 🎨 Frontend - client/

```
client/
├── src/
│   ├── 📂 pages/                       # الصفحات الرئيسية
│   │   ├── Home.tsx                    # الصفحة الرئيسية (Hero Section)
│   │   ├── Gallery.tsx                 # معرض الصور (Masonry Grid)
│   │   ├── ImageDetail.tsx             # تفاصيل الصورة (Lightbox)
│   │   ├── Upload.tsx                  # رفع الصور (Drag & Drop)
│   │   ├── Dashboard.tsx               # لوحة التحكم
│   │   ├── Profile.tsx                 # الملف الشخصي
│   │   ├── Pricing.tsx                 # صفحة الأسعار
│   │   ├── ComponentShowcase.tsx       # عرض المكونات
│   │   └── NotFound.tsx                # صفحة 404
│   │
│   ├── 📂 components/                  # المكونات المعاد استخدامها
│   │   ├── DashboardLayout.tsx         # تخطيط لوحة التحكم
│   │   ├── DashboardLayoutSkeleton.tsx # تحميل الهيكل
│   │   ├── ErrorBoundary.tsx           # معالج الأخطاء
│   │   ├── AIChatBox.tsx               # صندوق الدردشة
│   │   ├── Map.tsx                     # خريطة Google
│   │   ├── ManusDialog.tsx             # حوار مخصص
│   │   └── 📂 ui/                      # مكونات shadcn/ui
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── dialog.tsx
│   │       ├── input.tsx
│   │       ├── label.tsx
│   │       ├── badge.tsx
│   │       ├── skeleton.tsx
│   │       ├── spinner.tsx
│   │       ├── sonner.tsx              # إشعارات Toast
│   │       └── ... (30+ مكون)
│   │
│   ├── 📂 hooks/                       # React Hooks المخصصة
│   │   ├── useComposition.ts
│   │   ├── useMobile.tsx
│   │   └── usePersistFn.ts
│   │
│   ├── 📂 contexts/                    # React Contexts
│   │   └── ThemeContext.tsx            # السياق الليلي/النهاري
│   │
│   ├── 📂 lib/                         # المكتبات والأدوات
│   │   ├── trpc.ts                     # إعدادات tRPC Client
│   │   └── utils.ts                    # دوال مساعدة
│   │
│   ├── 📂 _core/                       # الملفات الأساسية
│   │   └── hooks/
│   │       └── useAuth.ts              # خطاف المصادقة
│   │
│   ├── App.tsx                         # المكون الرئيسي
│   ├── main.tsx                        # نقطة الدخول
│   ├── index.css                       # الأنماط العامة
│   └── const.ts                        # الثوابت
│
├── public/
│   ├── favicon.ico
│   ├── robots.txt
│   └── __manus__/
│       └── version.json
│
└── index.html                          # ملف HTML الرئيسي
```

### 🖥️ Backend - server/

```
server/
├── routers.ts                          # تعريفات tRPC Procedures
│   ├── auth.me                         # الحصول على المستخدم
│   ├── auth.logout                     # تسجيل الخروج
│   ├── gallery.getPublicImages         # الصور العامة
│   ├── gallery.getImageById            # صورة محددة
│   ├── gallery.getUserImages           # صور المستخدم
│   ├── favorites.list                  # قائمة المفضلة
│   ├── favorites.add                   # إضافة للمفضلة
│   ├── favorites.remove                # إزالة من المفضلة
│   ├── favorites.isFavorited           # التحقق من المفضلة
│   ├── subscriptions.getPlans          # الحصول على الخطط
│   └── subscriptions.getUserSubscription
│
├── db.ts                               # دوال قاعدة البيانات
│   ├── getDb()                         # الاتصال بقاعدة البيانات
│   ├── upsertUser()                    # إدراج/تحديث المستخدم
│   ├── getUserByOpenId()               # الحصول على المستخدم
│   ├── getPublicImages()               # الصور العامة
│   ├── getImageById()                  # صورة محددة
│   ├── getUserImages()                 # صور المستخدم
│   ├── getUserFavorites()              # المفضلة
│   ├── addToFavorites()                # إضافة للمفضلة
│   ├── removeFromFavorites()           # إزالة من المفضلة
│   ├── isFavorited()                   # التحقق من المفضلة
│   └── getSubscriptionPlans()          # خطط الاشتراكات
│
├── storage.ts                          # إدارة التخزين السحابي
│   ├── storagePut()                    # رفع ملف
│   └── storageGet()                    # الحصول على ملف
│
├── auth.logout.test.ts                 # اختبارات المصادقة
├── gallery.test.ts                     # اختبارات المعرض
│
└── 📂 _core/                           # الملفات الأساسية
    ├── index.ts                        # نقطة دخول الخادم
    ├── context.ts                      # سياق tRPC
    ├── trpc.ts                         # إعدادات tRPC Server
    ├── cookies.ts                      # إدارة الـ Cookies
    ├── oauth.ts                        # معالج OAuth
    ├── env.ts                          # متغيرات البيئة
    ├── llm.ts                          # تكامل LLM
    ├── imageGeneration.ts              # توليد الصور
    ├── voiceTranscription.ts           # تحويل الصوت
    ├── notification.ts                 # الإشعارات
    ├── heartbeat.ts                    # المهام الدورية
    ├── map.ts                          # خريطة Google
    ├── dataApi.ts                      # API البيانات
    ├── sdk.ts                          # SDK
    ├── storageProxy.ts                 # وكيل التخزين
    ├── vite.ts                         # تكامل Vite
    ├── systemRouter.ts                 # موجه النظام
    └── types/
        └── manusTypes.ts               # أنواع Manus
```

### 🗄️ Database - drizzle/

```
drizzle/
├── schema.ts                           # هيكل الجداول
│   ├── users                           # جدول المستخدمين
│   ├── images                          # جدول الصور
│   ├── favorites                       # جدول المفضلة
│   ├── subscription_plans              # جدول خطط الاشتراكات
│   └── user_subscriptions              # جدول اشتراكات المستخدمين
│
├── relations.ts                        # العلاقات بين الجداول
│
├── migrations/                         # ملفات الهجرة
│   ├── 0001_abandoned_valkyrie.sql     # إنشاء الجداول الأولى
│   └── ...
│
├── meta/                               # بيانات وصفية
│   └── _journal.json
│
└── drizzle.config.ts                   # إعدادات Drizzle
```

### 📦 Shared - shared/

```
shared/
├── const.ts                            # الثوابت المشتركة
│   ├── COOKIE_NAME
│   └── ...
│
├── types.ts                            # الأنواع المشتركة
│
└── 📂 _core/
    └── errors.ts                       # معالجة الأخطاء
```

### 💾 Storage - storage/

```
storage/
└── (ملفات التخزين السحابي)
```

---

## 📋 ملفات الإعدادات الرئيسية

### package.json
```json
{
  "name": "wallpix",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "NODE_ENV=development tsx watch server/_core/index.ts",
    "build": "vite build && esbuild ...",
    "start": "NODE_ENV=production node dist/index.js",
    "test": "vitest run",
    "check": "tsc --noEmit",
    "format": "prettier --write ."
  }
}
```

### tsconfig.json
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "jsx": "react-jsx",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "paths": {
      "@/*": ["./client/src/*"]
    }
  }
}
```

### vite.config.ts
```typescript
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000
  }
})
```

### tailwind.config.js
```javascript
export default {
  content: [
    './client/index.html',
    './client/src/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: '#7C3AED',
        secondary: '#0EA5E9'
      }
    }
  }
}
```

---

## 🔄 تدفق البيانات

### المصادقة
```
User → OAuth Login → Manus OAuth Server → /api/oauth/callback → Session Cookie → Authenticated
```

### المعرض
```
Frontend → trpc.gallery.getPublicImages → Backend → Database → Images Array → Display
```

### المفضلة
```
User Click → trpc.favorites.add → Backend → Database Insert → Update UI → Success Toast
```

### الرفع
```
Drag & Drop → File Validation → storagePut → S3 → Database Insert → Success
```

---

## 🎯 الملفات المهمة للتعديل

### للتطوير الأمامي (Frontend)
- `client/src/pages/*.tsx` - الصفحات
- `client/src/components/*.tsx` - المكونات
- `client/src/index.css` - الأنماط

### للتطوير الخلفي (Backend)
- `server/routers.ts` - tRPC Procedures
- `server/db.ts` - دوال قاعدة البيانات
- `drizzle/schema.ts` - هيكل الجداول

### للاختبارات
- `server/*.test.ts` - ملفات الاختبارات

---

## 📊 إحصائيات المشروع

| المقياس | القيمة |
|--------|--------|
| ملفات TypeScript | 50+ |
| مكونات React | 30+ |
| اختبارات Vitest | 10+ |
| أسطر الكود (Frontend) | ~3000 |
| أسطر الكود (Backend) | ~1500 |
| حجم الحزمة | ~150KB |

---

## 🚀 أوامر مهمة

```bash
# التطوير
pnpm dev

# الاختبارات
pnpm test

# البناء
pnpm build

# الإنتاج
pnpm start

# التحقق من الأخطاء
pnpm check

# تنسيق الكود
pnpm format

# إنشاء الهجرات
pnpm drizzle-kit generate

# تطبيق الهجرات
pnpm drizzle-kit migrate
```

---

## 📝 ملاحظات مهمة

1. **لا تعدل** الملفات تحت `_core` إلا إذا كنت تعرف ما تفعله
2. **استخدم** `trpc` للاتصال بالـ Backend
3. **احفظ** البيانات في قاعدة البيانات، لا في الملفات المحلية
4. **اختبر** جميع التغييرات قبل الدمج
5. **استخدم** `pnpm` بدلاً من `npm` أو `yarn`

---

**آخر تحديث:** 13 يونيو 2026
**الإصدار:** 1.0.0
