import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { uploadRouter } from "./upload-router";
import { adminRouter } from "./admin-router";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  gallery: router({
    getPublicImages: publicProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(({ input }) => db.getPublicImages(input.limit, input.offset)),

    getImageById: publicProcedure
      .input(z.number())
      .query(({ input }) => db.getImageById(input)),

    getUserImages: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(({ ctx, input }) => db.getUserImages(ctx.user.id, input.limit, input.offset)),
  }),

  favorites: router({
    list: protectedProcedure
      .query(({ ctx }) => db.getUserFavorites(ctx.user.id)),

    add: protectedProcedure
      .input(z.number())
      .mutation(({ ctx, input }) => db.addToFavorites(ctx.user.id, input)),

    remove: protectedProcedure
      .input(z.number())
      .mutation(({ ctx, input }) => db.removeFromFavorites(ctx.user.id, input)),

    isFavorited: protectedProcedure
      .input(z.number())
      .query(({ ctx, input }) => db.isFavorited(ctx.user.id, input)),
  }),

  subscriptions: router({
    getPlans: publicProcedure
      .query(() => db.getSubscriptionPlans()),

    getUserSubscription: protectedProcedure
      .query(({ ctx }) => db.getUserSubscription(ctx.user.id)),
  }),

  credits: router({
    getBalance: protectedProcedure
      .query(({ ctx }) => db.getUserCredits(ctx.user.id)),

    addCredits: protectedProcedure
      .input(z.object({ amount: z.number().positive(), paymentMethod: z.string().optional(), transactionId: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        try {
          await db.addCredits(ctx.user.id, input.amount);
          await db.createTransaction({
            userId: ctx.user.id,
            type: "credit_purchase",
            amount: input.amount.toString(),
            credits: input.amount,
            paymentMethod: input.paymentMethod || "unknown",
            transactionId: input.transactionId,
            status: "completed",
          });
          return { success: true, credits: input.amount };
        } catch (error) {
          console.error("[Credits] Add credits error:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to add credits" });
        }
      }),
  }),

  download: router({
    downloadImage: protectedProcedure
      .input(z.object({ imageId: z.number(), costInCredits: z.number().default(1) }))
      .mutation(async ({ ctx, input }) => {
        try {
          const image = await db.getImageById(input.imageId);
          if (!image) {
            throw new TRPCError({ code: "NOT_FOUND", message: "Image not found" });
          }

          const credits = await db.getUserCredits(ctx.user.id);
          if (credits < input.costInCredits) {
            throw new TRPCError({ code: "FORBIDDEN", message: "Insufficient credits" });
          }

          await db.deductCredits(ctx.user.id, input.costInCredits);
          await db.incrementImageDownloads(input.imageId);
          await db.createTransaction({
            userId: ctx.user.id,
            type: "download",
            amount: "0",
            credits: input.costInCredits,
            paymentMethod: "credits",
            transactionId: `download_${input.imageId}_${Date.now()}`,
            status: "completed",
          });

          return { success: true, downloadUrl: image.fileUrl };
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("[Download] Download error:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to process download" });
        }
      }),

    incrementViews: publicProcedure
      .input(z.number())
      .mutation(async ({ input }) => {
        try {
          await db.incrementImageViews(input);
          return { success: true };
        } catch (error) {
          console.error("[Download] Increment views error:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to increment views" });
        }
      }),
  }),

  categories: router({
    getAll: publicProcedure
      .query(() => db.getCategories()),

    getBySlug: publicProcedure
      .input(z.string())
      .query(({ input }) => db.getCategoryBySlug(input)),

    getImages: publicProcedure
      .input(z.object({ categoryId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(({ input }) => db.getImagesByCategory(input.categoryId, input.limit, input.offset)),
  }),

  upload: uploadRouter,

  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
