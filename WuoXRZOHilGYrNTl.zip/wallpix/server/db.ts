import { eq, and, desc, inArray, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, images, favorites, subscriptionPlans, userSubscriptions, InsertImage, InsertFavorite, transactions, categories, InsertTransaction } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    await db
      .insert(users)
      .values(values)
      .onDuplicateKeyUpdate({
        set: updateSet,
      });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getImageById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(images).where(eq(images.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getPublicImages(limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(images)
    .where(eq(images.isPublic, true))
    .orderBy(desc(images.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function createImage(data: InsertImage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(images).values(data);
  return result;
}

// Favorites queries
export async function getUserFavorites(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const favs = await db.select().from(favorites).where(eq(favorites.userId, userId));
  if (favs.length === 0) return [];
  const imageIds = favs.map(f => f.imageId);
  if (imageIds.length === 0) return [];
  return await db.select().from(images).where(inArray(images.id, imageIds));
}

export async function addToFavorites(userId: number, imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(favorites).values({ userId, imageId });
}

export async function removeFromFavorites(userId: number, imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db
    .delete(favorites)
    .where(and(eq(favorites.userId, userId), eq(favorites.imageId, imageId)));
}

export async function isFavorite(userId: number, imageId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(favorites)
    .where(and(eq(favorites.userId, userId), eq(favorites.imageId, imageId)))
    .limit(1);
  return result.length > 0;
}

// Subscription queries
export async function getSubscriptionPlans() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(subscriptionPlans);
}

export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(userSubscriptions)
    .where(eq(userSubscriptions.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createUserSubscription(data: InsertUserSubscription) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(userSubscriptions).values(data);
}

// Transaction queries
export async function createTransaction(data: InsertTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(transactions).values(data);
}

export async function getUserTransactions(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

// Category queries
export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(categories).orderBy(categories.nameAr);
}

export async function getCategoryBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getImagesByCategory(categoryId: number, limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(images).where(eq(images.isPublic, true)).orderBy(desc(images.createdAt)).limit(limit).offset(offset);
}

export async function incrementImageDownloads(imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(images).set({ downloadCount: sql`${images.downloadCount} + 1` }).where(eq(images.id, imageId));
}

export async function incrementImageViews(imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // viewCount field not in current schema - skip this
  return null;
}


// Admin functions
export async function getPendingImages(limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  // status field not in current schema - return all images
  return await db
    .select()
    .from(images)
    .orderBy(desc(images.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function approveImage(imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Removed status field - not in current schema
  return await db
    .delete(images)
    .where(eq(images.id, imageId));
}

export async function rejectImage(imageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Removed status field - not in current schema
  return await db
    .delete(images)
    .where(eq(images.id, imageId));
}

export async function getStats() {
  const db = await getDb();
  if (!db) return { totalImages: 0, totalUsers: 0, totalDownloads: 0 };

  try {
    const [imageCount] = await db.select({ count: sql`COUNT(*)` }).from(images);
    const [userCount] = await db.select({ count: sql`COUNT(*)` }).from(users);
    const [downloadCount] = await db.select({ count: sql`SUM(${images.downloadCount})` }).from(images);

    return {
      totalImages: Number(imageCount?.count || 0),
      totalUsers: Number(userCount?.count || 0),
      totalDownloads: Number(downloadCount?.count || 0),
    };
  } catch (error) {
    console.error("[Database] Failed to get stats:", error);
    return { totalImages: 0, totalUsers: 0, totalDownloads: 0 };
  }
}

export type InsertUserSubscription = typeof userSubscriptions.$inferInsert;


// Credit management functions
export async function getUserCredits(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const user = await getUserById(userId);
  return user?.credits || 0;
}

export async function addCredits(userId: number, amount: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db
    .update(users)
    .set({ credits: sql`${users.credits} + ${amount}` })
    .where(eq(users.id, userId));
}

export async function deductCredits(userId: number, amount: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db
    .update(users)
    .set({ credits: sql`${users.credits} - ${amount}` })
    .where(eq(users.id, userId));
}

// Admin user creation
export async function createAdminUser(openId: string, name: string, email: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(users).values({
    openId,
    name,
    email,
    role: "admin",
    credits: 1000,
  });
}


// User images
export async function getUserImages(userId: number, limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(images)
    .where(eq(images.userId, userId))
    .orderBy(desc(images.createdAt))
    .limit(limit)
    .offset(offset);
}

// Alias for isFavorite
export async function isFavorited(userId: number, imageId: number) {
  return await isFavorite(userId, imageId);
}
