import { describe, it, expect, beforeEach, vi } from "vitest";
import * as db from "./db";

describe("Gallery Functions", () => {
  describe("getPublicImages", () => {
    it("should return empty array when no images exist", async () => {
      const images = await db.getPublicImages(20, 0);
      expect(Array.isArray(images)).toBe(true);
    });

    it("should respect limit parameter", async () => {
      const images = await db.getPublicImages(5, 0);
      expect(images.length).toBeLessThanOrEqual(5);
    });

    it("should respect offset parameter", async () => {
      const firstBatch = await db.getPublicImages(10, 0);
      const secondBatch = await db.getPublicImages(10, 10);
      // Both should be arrays (may be empty if no images exist)
      expect(Array.isArray(firstBatch)).toBe(true);
      expect(Array.isArray(secondBatch)).toBe(true);
    });
  });

  describe("Favorites", () => {
    const testUserId = 1;
    const testImageId = 1;

    it("should add image to favorites", async () => {
      try {
        await db.addToFavorites(testUserId, testImageId);
        const isFav = await db.isFavorited(testUserId, testImageId);
        expect(isFav).toBe(true);
      } catch (error) {
        // Expected if image doesn't exist
        expect(error).toBeDefined();
      }
    });

    it("should remove image from favorites", async () => {
      try {
        await db.removeFromFavorites(testUserId, testImageId);
        const isFav = await db.isFavorited(testUserId, testImageId);
        expect(isFav).toBe(false);
      } catch (error) {
        // Expected if image doesn't exist
        expect(error).toBeDefined();
      }
    });

    it("should get user favorites", async () => {
      const favorites = await db.getUserFavorites(testUserId);
      expect(Array.isArray(favorites)).toBe(true);
    });
  });

  describe("Subscriptions", () => {
    it("should get all subscription plans", async () => {
      const plans = await db.getSubscriptionPlans();
      expect(Array.isArray(plans)).toBe(true);
      expect(plans.length).toBeGreaterThan(0);
    });

    it("should have correct plan names", async () => {
      const plans = await db.getSubscriptionPlans();
      const planNames = plans.map(p => p.name);
      expect(planNames).toContain("free");
      expect(planNames).toContain("pro");
      expect(planNames).toContain("enterprise");
    });

    it("should have correct pricing", async () => {
      const plans = await db.getSubscriptionPlans();
      const freePlan = plans.find(p => p.name === "free");
      const proPlan = plans.find(p => p.name === "pro");
      
      expect(parseFloat(freePlan?.price || "0")).toBe(0);
      expect(parseFloat(proPlan?.price || "0")).toBe(9.99);
    });
  });
});
