import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "You don't have permission to access this resource",
    });
  }
  return next({ ctx });
});

export const adminRouter = router({
  // Get pending images for review
  getPendingImages: adminProcedure
    .input(
      z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(({ input }) => db.getPendingImages(input.limit, input.offset)),

  // Approve an image
  approveImage: adminProcedure
    .input(z.number())
    .mutation(async ({ input }) => {
      try {
        await db.approveImage(input);
        return {
          success: true,
          message: "تم الموافقة على الصورة بنجاح",
        };
      } catch (error) {
        console.error("[Admin] Approve image error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل الموافقة على الصورة",
        });
      }
    }),

  // Reject an image
  rejectImage: adminProcedure
    .input(z.number())
    .mutation(async ({ input }) => {
      try {
        await db.rejectImage(input);
        return {
          success: true,
          message: "تم رفض الصورة بنجاح",
        };
      } catch (error) {
        console.error("[Admin] Reject image error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل رفض الصورة",
        });
      }
    }),

  // Get admin stats
  getStats: adminProcedure.query(async () => {
    try {
      const stats = await db.getStats();
      return stats;
    } catch (error) {
      console.error("[Admin] Stats query error:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "فشل جلب الإحصائيات",
      });
    }
  }),
});
