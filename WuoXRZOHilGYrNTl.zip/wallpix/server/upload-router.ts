import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const uploadRouter = router({
  uploadImage: protectedProcedure
    .input(
      z.object({
        fileName: z.string(),
        fileData: z.string(), // base64 encoded
        fileType: z.enum(["image/png", "image/jpeg", "image/webp"]),
        title: z.string().optional(),
        description: z.string().optional(),
        isPublic: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // Validate file
        if (!input.fileName) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "اسم الملف مطلوب" });
        }

        // Validate base64 data
        if (!input.fileData || input.fileData.length === 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "الملف فارغ" });
        }

        // Create data URL for direct display
        const dataUrl = `data:${input.fileType};base64,${input.fileData}`;
        
        // Calculate file size from base64
        const fileSize = Math.ceil((input.fileData.length * 3) / 4);

        // Save to database with Base64 data
        await db.createImage({
          userId: ctx.user.id,
          title: input.title || input.fileName,
          description: input.description || "",
          fileUrl: dataUrl, // Store data URL directly
          fileKey: `base64-${ctx.user.id}-${Date.now()}`,
          fileName: input.fileName,
          mimeType: input.fileType,
          fileSize: fileSize,
          isPublic: input.isPublic,
          imageData: input.fileData,
        });

        return {
          success: true,
          message: "تم رفع الصورة بنجاح",
          image: {
            titleAr: input.title || input.fileName,
            fileUrl: dataUrl,
          },
        };
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        console.error("[Upload] Upload error:", {
          message: errorMessage,
          stack: error instanceof Error ? error.stack : undefined,
          input: { fileName: input.fileName, fileType: input.fileType, fileDataLength: input.fileData.length },
          userId: ctx.user.id,
        });
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `فشل رفع الصورة: ${errorMessage}`,
        });
      }
    }),

  uploadMultiple: protectedProcedure
    .input(
      z.object({
        files: z.array(
          z.object({
            fileName: z.string(),
            fileData: z.string(),
            fileType: z.enum(["image/png", "image/jpeg", "image/webp"]),
            title: z.string().optional(),
            description: z.string().optional(),
          })
        ),
        isPublic: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const uploadedImages = [];
        const errors = [];

        for (const file of input.files) {
          try {
            // Validate file data
            if (!file.fileData || file.fileData.length === 0) {
              errors.push(`${file.fileName}: الملف فارغ`);
              continue;
            }

            // Create data URL
            const dataUrl = `data:${file.fileType};base64,${file.fileData}`;
            const fileSize = Math.ceil((file.fileData.length * 3) / 4);

            // Save to database
            await db.createImage({
              userId: ctx.user.id,
              title: file.title || file.fileName,
              description: file.description || "",
              fileUrl: dataUrl,
              fileKey: `base64-${ctx.user.id}-${Date.now()}-${Math.random()}`,
              fileName: file.fileName,
              mimeType: file.fileType,
              fileSize: fileSize,
              isPublic: input.isPublic,
              imageData: file.fileData,
            });

            uploadedImages.push({
              titleAr: file.title || file.fileName,
              fileUrl: dataUrl,
            });
          } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            console.error(`[Upload] Error uploading ${file.fileName}:`, {
              message: errorMessage,
              stack: error instanceof Error ? error.stack : undefined,
              fileName: file.fileName,
              fileType: file.fileType,
              fileDataLength: file.fileData.length,
            });
            errors.push(`${file.fileName}: ${errorMessage}`);
          }
        }

        if (uploadedImages.length === 0) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "فشل رفع جميع الصور",
          });
        }

        return {
          success: true,
          message: `تم رفع ${uploadedImages.length} صورة بنجاح`,
          uploadedImages,
          errors: errors.length > 0 ? errors : undefined,
        };
      } catch (error) {
        console.error("[Upload] Batch upload error:", error);
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "فشل رفع الصور. يرجى المحاولة مرة أخرى.",
        });
      }
    }),
});
