# 🚀 دليل البدء السريع

## 1️⃣ التثبيت الأساسي

```bash
# الانتقال إلى مجلد المشروع
cd /home/ubuntu/wallpix

# تثبيت المكتبات
pnpm install

# تشغيل الموقع
pnpm dev
```

## 2️⃣ الوصول إلى الموقع

```
🌐 الرابط: https://3000-igqr6yh6mmbbq3scjwzxf-d025ef50.us1.manus.computer
```

## 3️⃣ الصفحات الرئيسية

| الصفحة | الرابط | الوصف |
|-------|--------|-------|
| الرئيسية | `/` | الصفحة الرئيسية مع Hero Section |
| المعرض | `/gallery` | عرض جميع الصور |
| الأسعار | `/pricing` | خطط الاشتراكات |
| الرفع | `/upload` | رفع صور جديدة |
| لوحة التحكم | `/dashboard` | إحصائيات المستخدم |
| الملف الشخصي | `/profile` | إدارة البيانات |

## 4️⃣ الأوامر المهمة

```bash
# تشغيل الاختبارات
pnpm test

# البناء للإنتاج
pnpm build

# تشغيل الإنتاج
pnpm start

# فحص الأخطاء
pnpm check

# تنسيق الكود
pnpm format
```

## 5️⃣ متغيرات البيئة المطلوبة

```bash
DATABASE_URL=mysql://user:password@localhost:3306/wallpix
JWT_SECRET=your-secret-key
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
```

## 6️⃣ معلومات قاعدة البيانات

**الجداول الرئيسية:**
- `users` - المستخدمون
- `images` - الصور
- `favorites` - المفضلة
- `subscription_plans` - خطط الاشتراكات
- `user_subscriptions` - اشتراكات المستخدمين

## 7️⃣ المكونات الرئيسية

```
Frontend:
- React 19 + TypeScript
- Tailwind CSS 4
- shadcn/ui Components
- Framer Motion

Backend:
- Express.js + tRPC
- Drizzle ORM
- MySQL/TiDB
```

## 8️⃣ الاختبارات

```bash
# تشغيل جميع الاختبارات
pnpm test

# النتائج المتوقعة:
✅ 10 اختبارات تمر بنجاح
```

## 9️⃣ الدعم والمساعدة

- 📖 اقرأ `WEBSITE_INFO.md` للمعلومات الكاملة
- 📖 اقرأ `README_AR.md` للتفاصيل الشاملة
- 🐛 تحقق من `.manus-logs/` للأخطاء

## 🔟 الخطوات التالية

1. ✅ تثبيت المكتبات
2. ✅ إعداد قاعدة البيانات
3. ✅ تشغيل الموقع
4. ✅ اختبار الوظائف
5. ✅ نشر الموقع

---

**تم إنشاؤه:** 13 يونيو 2026
**الإصدار:** 1.0.0
**الحالة:** ✅ جاهز
