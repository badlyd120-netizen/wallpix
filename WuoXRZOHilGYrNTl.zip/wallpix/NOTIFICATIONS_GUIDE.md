# 📢 دليل نظام الإشعارات المخصص

## نظرة عامة

تم بناء نظام إشعارات احترافي ومخصص للموقع يوفر تجربة مستخدم سلسة وجذابة.

---

## 🎯 المميزات الرئيسية

### 1. أنواع الإشعارات
- **✅ النجاح** (Success) - أخضر
- **❌ الخطأ** (Error) - أحمر
- **⚠️ التحذير** (Warning) - أصفر
- **ℹ️ المعلومات** (Info) - أزرق

### 2. الرسوم المتحركة
- ظهور سلس من الأعلى (Slide-in)
- اختفاء تدريجي (Fade-out)
- مدة الظهور قابلة للتخصيص

### 3. الموضع
- أعلى يمين الصفحة (Top-right)
- يتراص عند وجود عدة إشعارات
- يدعم الوضع الليلي والنهاري

### 4. الإجراءات الإضافية
- زر إغلاق يدوي
- إجراء مخصص (مثل: عرض المعرض)
- مدة ظهور تلقائية أو يدوية

---

## 📚 طريقة الاستخدام

### الخطوة 1: استيراد Hook

```typescript
import { useNotifications } from '@/hooks/useNotifications';
```

### الخطوة 2: استخدام في المكون

```typescript
export default function MyComponent() {
  const notifications = useNotifications();

  const handleSuccess = () => {
    notifications.success('العملية نجحت', 'تم حفظ البيانات بنجاح');
  };

  return <button onClick={handleSuccess}>احفظ</button>;
}
```

---

## 🔧 الدوال المتاحة

### 1. إشعار النجاح
```typescript
notifications.success(title, message?, options?)
```

**مثال:**
```typescript
notifications.success(
  'تم الرفع بنجاح! 🎉',
  'تم رفع 3 صور',
  {
    duration: 5000,
    action: {
      label: 'عرض المعرض',
      onClick: () => navigate('/gallery')
    }
  }
);
```

### 2. إشعار الخطأ
```typescript
notifications.error(title, message?, options?)
```

**مثال:**
```typescript
notifications.error(
  'فشل الرفع',
  'حجم الملف كبير جداً'
);
```

### 3. إشعار التحذير
```typescript
notifications.warning(title, message?, options?)
```

**مثال:**
```typescript
notifications.warning(
  'ملف غير صالح',
  'الصيغة غير مدعومة. استخدم PNG أو JPG'
);
```

### 4. إشعار المعلومات
```typescript
notifications.info(title, message?, options?)
```

**مثال:**
```typescript
notifications.info(
  'تم الحفظ',
  'تم حفظ التفضيلات الخاصة بك'
);
```

### 5. إشعار التحميل
```typescript
notifications.loading(title, message?)
```

**مثال:**
```typescript
const loadingId = notifications.loading(
  'جاري المعالجة...',
  'يرجى الانتظار'
);

// لاحقاً، أغلق الإشعار يدوياً إذا لزم الأمر
```

---

## ⚙️ خيارات الإشعار

```typescript
interface NotificationOptions {
  duration?: number;  // مدة الظهور بالميلي ثانية (0 = لا يغلق تلقائياً)
  action?: {
    label: string;    // نص الزر
    onClick: () => void;  // دالة عند النقر
  };
}
```

---

## 📋 مدد الظهور الافتراضية

| النوع | المدة الافتراضية |
|-------|-----------------|
| النجاح | 5 ثانية |
| الخطأ | 7 ثواني |
| التحذير | 6 ثواني |
| المعلومات | 5 ثواني |
| التحميل | لا يغلق تلقائياً |

---

## 🎨 التصميم والألوان

### الوضع النهاري
- **النجاح**: خلفية أخضر فاتح مع نص أخضر غامق
- **الخطأ**: خلفية أحمر فاتح مع نص أحمر غامق
- **التحذير**: خلفية أصفر فاتح مع نص أصفر غامق
- **المعلومات**: خلفية أزرق فاتح مع نص أزرق غامق

### الوضع الليلي
- **النجاح**: خلفية أخضر غامق مع نص أخضر فاتح
- **الخطأ**: خلفية أحمر غامق مع نص أحمر فاتح
- **التحذير**: خلفية أصفر غامق مع نص أصفر فاتح
- **المعلومات**: خلفية أزرق غامق مع نص أزرق فاتح

---

## 📂 الملفات المستخدمة

### 1. **NotificationCenter.tsx**
- المكون الرئيسي للإشعارات
- Context Provider للإدارة
- مكون العرض

### 2. **useNotifications.ts**
- Hook مخصص للاستخدام السهل
- دوال مساعدة لكل نوع إشعار

### 3. **App.tsx**
- تضمين NotificationProvider

---

## 💡 أمثلة عملية

### مثال 1: رفع صورة
```typescript
const handleUpload = async () => {
  const loadingId = notifications.loading('جاري الرفع...', 'يتم رفع الصورة');

  try {
    await uploadFile(file);
    notifications.success(
      'تم الرفع بنجاح! 🎉',
      'تم رفع الصورة بنجاح',
      {
        action: {
          label: 'عرض الصورة',
          onClick: () => navigate(`/image/${imageId}`)
        }
      }
    );
  } catch (error) {
    notifications.error('فشل الرفع', error.message);
  }
};
```

### مثال 2: إضافة إلى المفضلة
```typescript
const handleAddFavorite = async (imageId: number) => {
  try {
    await addToFavorites(imageId);
    notifications.success('تمت الإضافة', 'تم إضافة الصورة إلى المفضلة ❤️');
  } catch (error) {
    notifications.error('خطأ', 'فشل إضافة الصورة إلى المفضلة');
  }
};
```

### مثال 3: التحقق من الملف
```typescript
const validateFile = (file: File) => {
  if (!ALLOWED_TYPES.includes(file.type)) {
    notifications.warning(
      'ملف غير صالح',
      `الصيغة "${file.type}" غير مدعومة`
    );
    return false;
  }
  return true;
};
```

### مثال 4: تحديث الملف الشخصي
```typescript
const handleUpdateProfile = async (data: ProfileData) => {
  try {
    await updateProfile(data);
    notifications.success(
      'تم التحديث',
      'تم تحديث بيانات الملف الشخصي بنجاح'
    );
  } catch (error) {
    notifications.error(
      'خطأ في التحديث',
      'فشل تحديث البيانات. يرجى المحاولة مرة أخرى.'
    );
  }
};
```

---

## 🔍 استكشاف الأخطاء

### المشكلة: الإشعارات لا تظهر
**الحل:**
1. تأكد من استيراد `useNotifications` بشكل صحيح
2. تأكد من أن المكون داخل `NotificationProvider`
3. تحقق من console للأخطاء

### المشكلة: الإشعار يختفي سريعاً جداً
**الحل:**
```typescript
notifications.success('العنوان', 'الرسالة', { duration: 10000 });
```

### المشكلة: الإشعار لا يختفي
**الحل:**
```typescript
notifications.loading('جاري...'); // يختفي يدوياً فقط
```

---

## 🚀 الخطوات التالية

1. ✅ تم إنشاء نظام الإشعارات
2. ✅ تم تطبيقه على صفحة Upload
3. ✅ تم تطبيقه على صفحة Gallery
4. ⏳ تطبيقه على باقي الصفحات (Dashboard, Profile, إلخ)

---

## 📞 الدعم

للمزيد من المعلومات أو الإبلاغ عن مشاكل:
- اقرأ `README_AR.md`
- اقرأ `QUICK_START.md`
- تحقق من الأكواس في `client/src/components/NotificationCenter.tsx`

---

**آخر تحديث:** 13 يونيو 2026
**الإصدار:** 1.0.0
