-- Add new columns to users table
ALTER TABLE `users` 
ADD COLUMN `credits` int NOT NULL DEFAULT 10,
ADD COLUMN `isPremium` boolean NOT NULL DEFAULT false,
ADD COLUMN `premiumExpiry` timestamp NULL,
ADD COLUMN `language` enum('ar','en') NOT NULL DEFAULT 'ar';

-- Create categories table
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nameAr` varchar(100) NOT NULL,
	`nameEn` varchar(100) NOT NULL,
	`slug` varchar(100) NOT NULL UNIQUE,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `categories_id` PRIMARY KEY(`id`)
);

-- Create transactions table
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('credit_purchase','premium_subscription','download') NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`credits` int NOT NULL DEFAULT 0,
	`paymentMethod` varchar(50),
	`transactionId` varchar(255),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

-- Modify images table to add new columns
ALTER TABLE `images`
ADD COLUMN `categoryId` int,
ADD COLUMN `titleAr` varchar(255),
ADD COLUMN `titleEn` varchar(255),
ADD COLUMN `descriptionAr` text,
ADD COLUMN `descriptionEn` text,
ADD COLUMN `thumbnail` varchar(255),
ADD COLUMN `resolution` varchar(20),
ADD COLUMN `isPremium` boolean NOT NULL DEFAULT false,
ADD COLUMN `downloadCost` int NOT NULL DEFAULT 1,
ADD COLUMN `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
ADD COLUMN `viewCount` int NOT NULL DEFAULT 0,
ADD CONSTRAINT `images_categoryId_fk` FOREIGN KEY (`categoryId`) REFERENCES `categories`(`id`) ON DELETE SET NULL;

-- Copy data from title to titleAr and titleEn if they exist
UPDATE `images` SET `titleAr` = `title`, `titleEn` = `title` WHERE `titleAr` IS NULL;

-- Copy data from description to descriptionAr and descriptionEn if they exist
UPDATE `images` SET `descriptionAr` = `description`, `descriptionEn` = `description` WHERE `descriptionAr` IS NULL;

-- Update fileSize to bigint
ALTER TABLE `images` MODIFY COLUMN `fileSize` bigint NOT NULL;

-- Add foreign key for images.userId if not exists
ALTER TABLE `images` ADD CONSTRAINT `images_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE;

-- Add foreign key for favorites.userId if not exists
ALTER TABLE `favorites` ADD CONSTRAINT `favorites_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE;

-- Add foreign key for favorites.imageId if not exists
ALTER TABLE `favorites` ADD CONSTRAINT `favorites_imageId_fk` FOREIGN KEY (`imageId`) REFERENCES `images`(`id`) ON DELETE CASCADE;
